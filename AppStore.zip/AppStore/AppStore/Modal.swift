//
//  Modal.swift
//  AppStore
//
//  Created by Essam Mahmoud fathy on 10/24/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class AppCategory : NSObject{
    var name : String?
    var apps : [Apps]?
    override func setValue(_ value: Any?, forKey key: String) {
        if key == "app" {
            apps = [Apps]()
            for dict in value as! [[String : AnyObject]]{
                let app = Apps()
                app.setValuesForKeys(dict)
                apps?.append(app)
            }
        }else {
            super.setValue(value, forKey: key)
        }
    }
    static func fetchTeaturedApps(completionHandler : @escaping ([AppCategory]) -> ()){
        let string = "http://www.statsallday.com/appstore/featured"
        let url = URL(string: string)
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if error != nil{
                print(error)
                return
            }
            do{
                let json = try (JSONSerialization.jsonObject(with: data!, options: .mutableContainers)) as! [String : AnyObject]
                var appcat = [AppCategory]()
                for dic in json["categories"] as! [[String : AnyObject]]{
                    let appCategory = AppCategory()
                    appCategory.setValuesForKeys(dic)
                    appcat.append(appCategory)
                }
                DispatchQueue.main.async {
                    completionHandler(appcat)
                }
                
                print(appcat)
            }catch let err{
                print(err)
            }
        }.resume()
    }
    
    
    static func simpleAppsCat()->[AppCategory]{
        var bestNewApps = AppCategory()
        bestNewApps.name = "Best New Apps"
        var apps = [Apps]()
        let frozenApp = Apps()
        frozenApp.name = "Desney frozen"
        frozenApp.Category = "Entertainment"
        frozenApp.price = NSNumber(floatLiteral: 3.99)
        frozenApp.imageName = "b1"
        apps.append(frozenApp)
        
        var bestnewGames = AppCategory()
        bestNewApps.name = "Best New Games"
        var games = [Apps]()
        
        let telepaintApp = Apps()
        telepaintApp.name = "tele Paint"
        telepaintApp.Category = "Games"
        telepaintApp.price = NSNumber(floatLiteral: 2.95)
        telepaintApp.imageName = "b2"
        games.append(telepaintApp)
        
        bestnewGames.apps = games
        bestNewApps.apps = apps
        return [bestNewApps,bestnewGames]
    }
}
class Apps : NSObject{
    var id : NSNumber?
    var name : String?
    var Category : String?
    var imageName : String?
    var price : NSNumber?
    
}
