//
//  CategoryCell.swift
//  AppStore
//
//  Created by Essam Mahmoud fathy on 10/23/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit
class CategoryCell:UICollectionViewCell,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UICollectionViewDelegate {
    var appcategory : AppCategory?{
        didSet{
            if let name = appcategory?.name{
                 nameLable.text = name
            }
        }
    }
  
    let cellId = "appsCelId"
    let appCollectionView : UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let collectionview = UICollectionView(frame: .zero, collectionViewLayout: layout)
        layout.scrollDirection = .horizontal
        collectionview.backgroundColor = UIColor.clear
        collectionview.translatesAutoresizingMaskIntoConstraints = false
        return collectionview
    }()
    let dividerLine :UIView = {
       let view = UIView()
        view.backgroundColor = UIColor(white: 0.4, alpha: 0.4)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    let nameLable : UILabel = {
        let label = UILabel()
        label.text = "Top Rated"
        label.font = UIFont.systemFont(ofSize: 16)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not ben implemented ")
    }
    func setupViews(){
        backgroundColor = UIColor.white
        addSubview(appCollectionView)
        addSubview(dividerLine)
        addSubview(nameLable)
        appCollectionView.dataSource = self
        appCollectionView.delegate = self
        appCollectionView.register(AppCell.self, forCellWithReuseIdentifier: cellId)
        // add constrain to the collection view
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-14[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0" : nameLable]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-14-[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0" : dividerLine]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[nameLable(30)][v0][v1(0.5)]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["nameLable" : nameLable,"v0" : appCollectionView, "v1" : dividerLine]))
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[v0]|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0" : appCollectionView]))
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let count = appcategory?.apps?.count{
            return count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = appCollectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath) as! AppCell
        cell.app = (appcategory?.apps?[indexPath.item])!
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 100, height: frame.height - 32)
    }
    // to leave space from the left and the right of the collection view
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
    }
    
}




class AppCell: UICollectionViewCell{
    var app : Apps?{
        didSet{
            if let name = app?.name{
                nameLable.text = name
            }
            categoryLable.text = app?.Category
            if let price = app?.price{
                priceLable.text = "$\(price)"
            }
            else {
                priceLable.text = "Free"
            }
            if let image = app?.imageName{
                imageView.image = UIImage(named: image)
            }
            
            
        }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not ben implemented ")
    }
    let imageView: UIImageView = {
       let image = UIImageView()
        image.image = UIImage(named: "b1")
        image.contentMode = .scaleAspectFill
        image.layer.cornerRadius = 16
        image.layer.masksToBounds = true
        return image
    }()
    let nameLable : UILabel = {
        let name = UILabel()
    
        name.font = UIFont.systemFont(ofSize: 12)
        name.numberOfLines = 2
        return name
    }()
    let categoryLable : UILabel = {
       let label = UILabel()
        label.text = "Entertainment"
        label.font = UIFont.systemFont(ofSize: 13)
        label.numberOfLines = 2
        label.textColor = UIColor.darkGray
        return label
    }()
    let priceLable : UILabel = {
       let price = UILabel()
       price.text = "$ 15"
       price.font = UIFont.systemFont(ofSize: 13)
        price.textColor = UIColor.darkGray
        return price
    }()
    func setupViews(){
        backgroundColor = UIColor.clear
        addSubview(imageView)
        addSubview(nameLable)
        addSubview(categoryLable)
        addSubview(priceLable)
        imageView.frame = CGRect(x: 0, y: 0, width: frame.width, height: frame.width)
        nameLable.frame = CGRect(x: 0, y: frame.width + 2 , width: frame.width, height: 40)
        categoryLable.frame = CGRect(x: 0, y: frame.width + 38, width: frame.width, height: 20)
        priceLable.frame = CGRect(x: 0, y: frame.width + 56, width: frame.width, height: 20)
        
    }
}

